import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ContactmailService } from 'src/app/services/contactmail.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit{
  
  enquiryForm!: FormGroup ;
  submitted=false;
  mailapi:any;
  
  constructor( private formBuilder: FormBuilder, private mailApi: ContactmailService){}

  ngOnInit(): void {
    this.enquiryForm = this.formBuilder.group({
      name: ['', [Validators.required,Validators.minLength(4)]],
      email:['',[Validators.required,Validators.email]],
      adult:['',[Validators.required]],
      kids:['', [Validators.required]],
      arrival:['', [Validators.required]],
      departure:['', [Validators.required]]
    });
  }

  

  onSubmit(){
    this.submitted = true;
    if(this.enquiryForm.invalid){
      return
    }
    else{
      console.log(this.enquiryForm.value);
       this.mailApi.contactMail(this.enquiryForm.value).subscribe((mailresponse:any)=>{
         console.log(mailresponse);
       });
       alert("Email Sent Successfully");
       this.enquiryForm.reset();
    }
    //alert("Success")
  }

}
