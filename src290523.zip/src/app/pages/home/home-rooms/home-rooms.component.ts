import { Component } from '@angular/core';

@Component({
  selector: 'app-home-rooms',
  templateUrl: './home-rooms.component.html',
  styleUrls: ['./home-rooms.component.css']
})
export class HomeRoomsComponent {

}
